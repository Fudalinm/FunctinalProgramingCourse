hue ::Integer -> [Integer]
hue 0 = []
hue k= [k `mod` 256 ] ++( hue (k `div` 256))